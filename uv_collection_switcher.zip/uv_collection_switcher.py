bl_info = {
    "name": "UV Collection Switcher",
    "author": "Pavel Kruhlei",
    "version": (2, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > UV Switcher",
    "description": "Select collections, activate matching UV map and exclude the rest from view layer",
    "category": "Object",
}

import bpy
from bpy.props import StringProperty, EnumProperty
from bpy.types import Panel, Operator, PropertyGroup
from bpy.utils import register_class, unregister_class


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def get_all_collections_items(self, context):
    items = [("NONE", "— none —", "")]
    for col in bpy.data.collections:
        items.append((col.name, col.name, ""))
    return items


def find_layer_collection(layer_col, name):
    """Recursively find a layer collection by collection name."""
    if layer_col.collection.name == name:
        return layer_col
    for child in layer_col.children:
        result = find_layer_collection(child, name)
        if result:
            return result
    return None


def set_collection_excluded(context, col_name, excluded: bool):
    root = context.view_layer.layer_collection
    lc = find_layer_collection(root, col_name)
    if lc:
        lc.exclude = excluded


def set_all_collections_excluded(context, excluded: bool):
    root = context.view_layer.layer_collection

    def recurse(lc):
        if lc.collection.name != context.scene.collection.name:
            lc.exclude = excluded
        for child in lc.children:
            recurse(child)

    recurse(root)


def get_all_meshes_in_collection(col):
    """Return all mesh objects directly in a collection (non-recursive)."""
    return [obj for obj in col.objects if obj.type == "MESH"]


def get_all_meshes_in_collection_recursive(col):
    """Return all mesh objects in a collection and all its children."""
    meshes = list(get_all_meshes_in_collection(col))
    for child in col.children:
        meshes.extend(get_all_meshes_in_collection_recursive(child))
    return meshes


def find_matching_uv(obj, col_name: str):
    """Find UV map on obj whose name exactly matches col_name."""
    if not obj or obj.type != "MESH":
        return None
    return obj.data.uv_layers.get(col_name)


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------


class UVSProps(PropertyGroup):
    main_collection: EnumProperty(
        name="Main Collection",
        items=get_all_collections_items,
    )
    second_collection: EnumProperty(
        name="2nd Collection",
        items=get_all_collections_items,
    )
    last_result: StringProperty(default="")
    last_error: StringProperty(default="")
    show_uv_list: bpy.props.BoolProperty(
        name="Show UV List",
        default=False,
    )


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------


class UVS_OT_AddUVMaps(Operator):
    """Add UV maps to every mesh in every collection.\nEach collection's meshes get only their own UV map.\nEach UV map is named after its collection."""

    bl_idname = "uvs.add_uv_maps"
    bl_label = "Add UV Maps"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        created_uvs = []
        skipped_uvs = []

        all_collections = list(bpy.data.collections)

        for col in all_collections:
            meshes = get_all_meshes_in_collection_recursive(col)
            if not meshes:
                continue

            uv_name = col.name

            for obj in meshes:
                if obj.data.uv_layers.get(uv_name) is None:
                    obj.data.uv_layers.new(name=uv_name)
                    if uv_name not in created_uvs:
                        created_uvs.append(uv_name)
                else:
                    if uv_name not in skipped_uvs and uv_name not in created_uvs:
                        skipped_uvs.append(uv_name)

        created_str = ", ".join(sorted(created_uvs)) if created_uvs else "none"
        skipped_str = ", ".join(sorted(skipped_uvs)) if skipped_uvs else "none"

        props = context.scene.uvs_props
        props.last_result = f"Created: {created_str}"
        props.last_error = ""

        if created_uvs:
            self.report({"INFO"}, f"Added UVs: {created_str}")
        if skipped_uvs:
            self.report({"INFO"}, f"Already existed: {skipped_str}")

        return {"FINISHED"}


class UVS_OT_Activate(Operator):
    """Exclude all collections except selected ones,\nactivate matching UV map and select all meshes"""

    bl_idname = "uvs.activate"
    bl_label = "Activate"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.uvs_props
        main_name = props.main_collection
        second_name = props.second_collection

        if main_name == "NONE" and second_name == "NONE":
            props.last_error = "Select at least one collection"
            props.last_result = ""
            self.report({"WARNING"}, props.last_error)
            return {"CANCELLED"}

        selected_names = set()
        if main_name != "NONE":
            selected_names.add(main_name)
        if second_name != "NONE":
            selected_names.add(second_name)

        uv_target = second_name if second_name != "NONE" else main_name

        main_meshes = []
        second_meshes = []
        main_uv_added = False

        if main_name != "NONE":
            main_col = bpy.data.collections.get(main_name)
            if main_col:
                main_meshes = get_all_meshes_in_collection_recursive(main_col)

        if second_name != "NONE":
            second_col = bpy.data.collections.get(second_name)
            if second_col:
                second_meshes = get_all_meshes_in_collection_recursive(second_col)

        all_meshes = main_meshes + second_meshes

        for obj in main_meshes:
            while obj.data.uv_layers:
                obj.data.uv_layers.remove(obj.data.uv_layers[0])

        for obj in main_meshes:
            if second_name != "NONE":
                if obj.data.uv_layers.get(uv_target) is None:
                    obj.data.uv_layers.new(name=uv_target)
                uv = obj.data.uv_layers.get(uv_target)
                if uv:
                    for layer in obj.data.uv_layers:
                        layer.active_render = False
                    obj.data.uv_layers.active = uv
                    uv.active_render = True
                    main_uv_added = True

        for obj in second_meshes:
            uv = find_matching_uv(obj, uv_target)
            if uv:
                for layer in obj.data.uv_layers:
                    layer.active_render = False
                obj.data.uv_layers.active = uv
                uv.active_render = True

        set_all_collections_excluded(context, True)
        for name in selected_names:
            set_collection_excluded(context, name, False)

        bpy.ops.object.select_all(action="DESELECT")
        first_mesh = None
        for obj in all_meshes:
            obj.select_set(True)
            if first_mesh is None:
                first_mesh = obj

        if first_mesh:
            context.view_layer.objects.active = first_mesh

        if main_uv_added:
            props.last_result = uv_target
            props.last_error = ""
            self.report(
                {"INFO"}, f"Active UV: {uv_target} | Selected {len(all_meshes)} meshes"
            )
        else:
            props.last_error = f'No UV "{uv_target}" found on meshes'
            props.last_result = ""
            self.report({"WARNING"}, props.last_error)

        return {"FINISHED"}


class UVS_OT_ActivateAll(Operator):
    """Include all collections in view layer"""

    bl_idname = "uvs.activate_all"
    bl_label = "Activate All"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        set_all_collections_excluded(context, False)
        context.scene.uvs_props.last_result = ""
        context.scene.uvs_props.last_error = ""
        self.report({"INFO"}, "All collections activated")
        return {"FINISHED"}


class UVS_OT_DisableAll(Operator):
    """Exclude all collections from view layer"""

    bl_idname = "uvs.disable_all"
    bl_label = "Disable All"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        set_all_collections_excluded(context, True)
        context.scene.uvs_props.last_result = ""
        context.scene.uvs_props.last_error = ""
        self.report({"INFO"}, "All collections disabled")
        return {"FINISHED"}


class UVS_OT_ToggleUVList(Operator):
    """Show or hide the list of added UV maps"""

    bl_idname = "uvs.toggle_uv_list"
    bl_label = "Toggle UV List"

    def execute(self, context):
        context.scene.uvs_props.show_uv_list = not context.scene.uvs_props.show_uv_list
        return {"FINISHED"}


class UVS_OT_DeleteUVMap(Operator):
    """Delete this UV map from all meshes in all collections"""

    bl_idname = "uvs.delete_uv_map"
    bl_label = "Delete UV Map"
    bl_options = {"REGISTER", "UNDO"}

    uv_name: StringProperty()

    def execute(self, context):
        removed = 0
        for col in bpy.data.collections:
            for obj in get_all_meshes_in_collection_recursive(col):
                uv = obj.data.uv_layers.get(self.uv_name)
                if uv:
                    obj.data.uv_layers.remove(uv)
                    removed += 1
        self.report({"INFO"}, f'Removed "{self.uv_name}" from {removed} meshes')
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------


class UVS_PT_MainPanel(Panel):
    bl_label = "UV Selector"
    bl_idname = "UVS_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "UV Switcher"

    def draw(self, context):
        layout = self.layout
        props = context.scene.uvs_props
        obj = context.active_object

        # ── Add UVs for all Collections ────────────────────────────────────
        layout.operator(
            "uvs.add_uv_maps", icon="ADD", text="Add UVs for all Collections"
        )

        layout.separator()

        # ── Main collection ───────────────────────────────────────────────
        layout.label(text="Main collection:", icon="OUTLINER_COLLECTION")
        layout.prop(props, "main_collection", text="")

        layout.separator()

        # ── 2nd collection ────────────────────────────────────────────────
        layout.label(text="2nd collection:", icon="OUTLINER_COLLECTION")
        layout.prop(props, "second_collection", text="")

        layout.separator()

        # ── UV preview ────────────────────────────────────────────────────
        uv_target = (
            props.second_collection
            if props.second_collection != "NONE"
            else props.main_collection
        )
        box = layout.box()
        box.label(text="UV to activate:", icon="GROUP_UVS")
        if uv_target and uv_target != "NONE":
            # Check if this UV exists on active object
            if obj and obj.type == "MESH":
                exists = obj.data.uv_layers.get(uv_target) is not None
                icon = "CHECKMARK" if exists else "QUESTION"
                box.label(text=uv_target, icon=icon)
                if not exists:
                    box.label(text="Not found on active object", icon="INFO")
            else:
                box.label(text=uv_target)
        else:
            box.label(text="Select a collection", icon="INFO")

        layout.separator()

        # ── Activate button ───────────────────────────────────────────────
        row = layout.row()
        row.scale_y = 1.8
        row.operator("uvs.activate", icon="PLAY")

        # ── Feedback ──────────────────────────────────────────────────────
        if props.last_error:
            row2 = layout.row()
            row2.alert = True
            row2.label(text=props.last_error, icon="ERROR")
        elif props.last_result:
            layout.label(text=f"Active: {props.last_result}", icon="CHECKMARK")

        layout.separator()

        # ── Utility ───────────────────────────────────────────────────────
        row = layout.row(align=True)
        row.operator("uvs.activate_all", icon="HIDE_OFF")
        row.operator("uvs.disable_all", icon="HIDE_ON")

        layout.separator()

        # ── UV list toggle ────────────────────────────────────────────────
        list_label = (
            "Hide list of added UVs" if props.show_uv_list else "Show list of added UVs"
        )
        list_icon = "TRIA_DOWN" if props.show_uv_list else "TRIA_RIGHT"
        row = layout.row()
        row.operator("uvs.toggle_uv_list", text=list_label, icon=list_icon)

        if props.show_uv_list:
            # Collect unique UV names across all meshes in all collections
            uv_names = set()
            for col in bpy.data.collections:
                for obj in get_all_meshes_in_collection_recursive(col):
                    for uv in obj.data.uv_layers:
                        uv_names.add(uv.name)

            box = layout.box()
            if uv_names:
                for name in sorted(uv_names):
                    row = box.row(align=True)
                    row.label(text=name, icon="GROUP_UVS")
                    op = row.operator("uvs.delete_uv_map", text="", icon="X")
                    op.uv_name = name
            else:
                box.label(text="No UV maps found", icon="INFO")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    UVSProps,
    UVS_OT_AddUVMaps,
    UVS_OT_Activate,
    UVS_OT_ActivateAll,
    UVS_OT_DisableAll,
    UVS_OT_ToggleUVList,
    UVS_OT_DeleteUVMap,
    UVS_PT_MainPanel,
)


def register():
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.uvs_props = bpy.props.PointerProperty(type=UVSProps)


def unregister():
    del bpy.types.Scene.uvs_props
    for cls in reversed(classes):
        unregister_class(cls)


if __name__ == "__main__":
    register()
